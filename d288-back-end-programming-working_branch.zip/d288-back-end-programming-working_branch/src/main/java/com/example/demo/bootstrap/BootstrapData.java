package com.example.demo.bootstrap;

import com.example.demo.dao.CustomerRepository;
import com.example.demo.dao.DivisionRepository;
import com.example.demo.entities.Customer;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class BootstrapData implements CommandLineRunner {

    private final CustomerRepository customerRepository;
    private final DivisionRepository divisionRepository;

    public BootstrapData(CustomerRepository customerRepository, DivisionRepository divisionRepository) {
        this.customerRepository = customerRepository;
        this.divisionRepository = divisionRepository;
    }

    @Override
    public void run(String... args) throws Exception {

        Customer customer1 = new Customer("Billy", "Bob", "43 Highway lane", "43250", "5749230909", divisionRepository.getReferenceById(Long.valueOf(2)));
        Customer customer2 = new Customer("John", "Money", "29 Silly street", "48521", "5852074196", divisionRepository.getReferenceById(Long.valueOf(3)));
        Customer customer3 = new Customer("Frank", "Muniz", "423 Anime lane", "76431", "1593571235", divisionRepository.getReferenceById(Long.valueOf(4)));
        Customer customer4 = new Customer("George", "Thomas", "300 Dude alley", "98541", "4567891230", divisionRepository.getReferenceById(Long.valueOf(5)));
        Customer customer5 = new Customer("Parker", "Peter", "897 Harry ave", "37249", "0258369147", divisionRepository.getReferenceById(Long.valueOf(6)));

        customerRepository.save(customer1);
        customerRepository.save(customer2);
        customerRepository.save(customer3);
        customerRepository.save(customer4);
        customerRepository.save(customer5);
    }
}
